﻿lia.char.registerVar("partyTier", {
    field = "party_tier",
    fieldType = "integer",
    default = 0,
    noDisplay = true,
})
