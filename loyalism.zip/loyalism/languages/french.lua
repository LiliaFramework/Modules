﻿NAME = "French"
LANGUAGE = {
    generalinfo = "General Information",
    invalidPartyTier = "Invalid party tier.",
    mustBeOnCharacter = "You must be on your character to do that.",
    partyTier = "Loyalty Tier",
    partyTierDisplay = "Loyalty Tier: %s",
    partyTierRemoved = "Your loyalty tier has been cleared by %s.",
    partyTierSet = "Your loyalty tier is now %s.",
    partyTierUpdated = "%s's loyalty tier is now %s.",
    partytierCommandDesc = "Set a player's loyalty tier.",
    partyTiers = "Party Tiers"
}
