﻿MODULE.name = "Shoot Lock"
MODULE.versionID = "public_shootlock"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds the ability to shoot door locks to open them, a quick breach alternative, a loud action that may alert others, and chance-based lock destruction."
MODULE.Changelog = {
    ["1.0"] = "Initial Release",
}
