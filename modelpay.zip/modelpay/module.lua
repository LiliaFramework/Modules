﻿MODULE.name = "Model Pay"
MODULE.versionID = "public_modelpay"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds payment to characters based on model, custom wage definitions, integration into the economy, config to exclude certain models, and logs of wages issued."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
