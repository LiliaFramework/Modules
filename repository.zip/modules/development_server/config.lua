﻿MODULE.AuthorizedDevelopers = {"76561198312513285"}
lia.config.add("DevServer", "Developer Server Mode", false, nil, {
    desc = "Enables or disables developer server mode.",
    category = "Server",
    type = "Boolean"
})
