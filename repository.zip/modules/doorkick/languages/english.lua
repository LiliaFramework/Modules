﻿NAME = "english"
LANGUAGE = {
    doorKickTooWeak = "You are too weak to kick this door in!",
    doorKickTooClose = "You are too close to kick the door down!",
    doorKickTooFar = "You are too far to kick the door down!",
    doorKickInvalid = "You are looking at an invalid door",
    doorKickCannotKick = "This door can not be kicked in!"
}
