﻿NAME = "english"
LANGUAGE = {
    ToggleViewBob = "Toggle ViewBob.",
}
