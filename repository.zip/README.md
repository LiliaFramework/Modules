<h1 align="center">Lilia 
- Modules</h1>

<p align="center">
  <img src="https://i.imgur.com/yY3wT30.png" alt="Lilia Icon">
</p>

# Contents

- **AFK Manager**

- **Advert**

- **Alcoholism**

- **Announcements**

- **Anti ERP**

- **Body Grouper**

- **Broadcasts**

- **Captions**

- **Cassette Player**

- **Chat Messages**

- **Cinematic Text**

- **Climb**

- **CM Blocks**

- **Community Commands**

- **Compass**

- **Corpseid**

- **Custom Cursor**

- **Development Server**

- **Development HUD**

- **Donator Bundle**

- **Door Kicking**

- **Downtime Notifier**

- **Enhanced Death**

- **Extended Descriptions**

- **F1 Menu Expansions**

- **Flashlight**

- **Force Fields**

- **Free Look**

- **Join & Leave Messages**

- **Loyalism**

- **Map Cleaner**

- **Model Pay**

- **Model Tweaker**

- **Night Vision Goggles**

- **Notes**

- **NPC Spawner**

- **Perma Remove**

- **Perma Weapons**

- **Radio**

- **Raised Weapons**

- **Realistic Damage**

- **Realistic View**

- **Rumour**

- **Shoot Lock**

- **Spawn Menu Items**

- **Stun Gun**

- **Tying**

- **Utils**

- **View Bob**

- **Text to Speech Voices**

- **Voices**

- **Warrant**

- **War Table**

- **Whitelist**

# Support

If you have any questions or need assistance with any of the modules, or if you would like to engage with the community, feel free to join our [Discord Server](https://discord.gg/52MSnh39vw). You can find us at this Discord invite link. We are ready to help and support you in any way we can.