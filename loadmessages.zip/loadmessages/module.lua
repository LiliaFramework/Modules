﻿MODULE.name = "Load Messages"
MODULE.versionID = "public_loadmessages"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds faction-based load messages, execution when players first load a character, customizable message text, color-coded formatting options, and per-faction enable toggles."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
