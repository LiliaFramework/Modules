﻿MODULE.FactionMessages = {
    [FACTION_STAFF] = {Color(255, 215, 0), "Welcome, staff member. Monitor the server responsibly."}
}
