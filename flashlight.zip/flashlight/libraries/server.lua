﻿function MODULE:PlayerSwitchFlashlight(client, isEnabled)
    if not client:getChar() then return false end
    local enabled, needsItem, cooldown = lia.config.get("FlashlightEnabled", true), lia.config.get("FlashlightNeedsItem", true), lia.config.get("FlashlightCooldown", 0.5)
    if not enabled or (client.FlashlightCooldown or 0) >= CurTime() then return false end
    if needsItem then
        for _, item in pairs(client:getChar():getInv():getItems()) do
            if item.isFlashlight then
                client:EmitSound("buttons/button24.wav", 60, 100)
                client.FlashlightCooldown = CurTime() + cooldown
                client:ConCommand("r_shadows " .. (isEnabled and "1" or "0"))
                return true
            end
        end
        return false
    end

    client:EmitSound("buttons/button24.wav", 60, 100)
    client.FlashlightCooldown = CurTime() + cooldown
    client:ConCommand("r_shadows " .. (isEnabled and "1" or "0"))
    return true
end
