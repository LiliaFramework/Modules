﻿NAME = "Portuguese"
LANGUAGE = {
    enableFlashlight = "Enable Flashlight",
    enableFlashlightDesc = "Enables or disables the flashlight functionality.",
    flashlight = "Flashlight",
    flashlightRequiresItem = "Flashlight Requires Item",
    flashlightRequiresItemDesc = "Determines if a specific item is required to use the flashlight.",
    flashlightCooldown = "Flashlight Cooldown",
    flashlightCooldownDesc = "Sets the cooldown time (in seconds) between flashlight toggles.",
}