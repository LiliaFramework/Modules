﻿MODULE.name = "Flashlight"
MODULE.versionID = "public_flashlight"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds a serious flashlight with dynamic light, darkening of surroundings when turned off, adjustable brightness, and keybind toggle support."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
