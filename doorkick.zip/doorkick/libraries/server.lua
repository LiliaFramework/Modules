﻿util.AddNetworkString("DoorKickView")
