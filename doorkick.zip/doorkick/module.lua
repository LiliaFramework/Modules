﻿MODULE.name = "Door Kick"
MODULE.versionID = "public_doorkick"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds the ability to kick doors open with an animation, logging of door kick events, and a fun breach mechanic with physics force to fling doors open."
MODULE.NetworkStrings = {"DoorKickView"}
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
