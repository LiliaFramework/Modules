# Changelog

### Version 1.5

- Updated Vector method calls to use proper PascalCase naming (`distance` → `Distance`)

### Version 1.4

- Added comprehensive hooks documentation
- Added libraries documentation

### Version 1.2

- Updated function naming convention from PascalCase to camelCase for consistency:
  - `SpeedTest` → `speedTest`
  - `DaysBetween` → `daysBetween`
  - `LerpHSV` → `lerpHSV`
  - `Darken` → `darken`
  - `LerpColor` → `lerpColor`
  - `Blend` → `blend`
  - `Rainbow` → `rainbow`
  - `ColorCycle` → `colorCycle`
  - `ColorToHex` → `colorToHex`
  - `Lighten` → `lighten`
  - `SecondsToDHMS` → `secondsToDHMS`
  - `HMSToSeconds` → `hMSToSeconds`
  - `FormatTimestamp` → `formatTimestamp`
  - `WeekdayName` → `weekdayName`
  - `TimeUntil` → `timeUntil`
  - `CurrentLocalTime` → `currentLocalTime`
  - `TimeDifference` → `timeDifference`
  - `SerializeVector` → `serializeVector`
  - `DeserializeVector` → `deserializeVector`
  - `SerializeAngle` → `serializeAngle`
  - `DeserializeAngle` → `deserializeAngle`

### Version 1.1

- Created docs

### Version 1.0

- Initial Release
