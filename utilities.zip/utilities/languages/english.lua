﻿NAME = "English"
LANGUAGE = {
    invalidDates = "Invalid dates",
    invalidTimeFormat = "Invalid time format. Expected 'HH:MM:SS - DD/MM/YYYY'.",
    invalidTimeValues = "Invalid time values.",
    timeIsPast = "The specified time is in the past.",
    timeDifferenceFormat = "%d years, %d months, %d days, %d hours, %d minutes, %d seconds"
}
