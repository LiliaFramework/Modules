﻿NAME = "english"
LANGUAGE = {
    playerJoined = "%s entered the server.",
    playerLeft = "%s left the server.",
}
