﻿NAME = "english"
LANGUAGE = {
    moneyLossMessage = "You lost %s %s on death.",
}
