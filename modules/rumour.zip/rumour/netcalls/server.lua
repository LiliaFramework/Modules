﻿util.AddNetworkString("RumorMessageCall")
