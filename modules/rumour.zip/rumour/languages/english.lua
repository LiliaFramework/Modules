﻿NAME = "english"
LANGUAGE = {
    rumourNotAllowed = "You are not allowed to use /rumour.",
    rumourNoMessage = "You must provide a message for /rumour.",
    rumourMessagePrefix = "[Rumour]: %s",
}
