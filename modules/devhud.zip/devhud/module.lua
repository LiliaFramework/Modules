﻿MODULE.name = "Development HUD"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.version = "Stock"
MODULE.desc = "Adds a Development HUD"
MODULE.CAMIPrivileges = {
    {
        Name = "Staff Permissions - Staff HUD",
        MinAccess = "superadmin",
        Description = "Allows access to Staff HUD.",
    },
    {
        Name = "Staff Permissions - Development HUD",
        MinAccess = "superadmin",
        Description = "Allows access to Development HUD.",
    }
}
