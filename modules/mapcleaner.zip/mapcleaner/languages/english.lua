﻿NAME = "english"
LANGUAGE = {
    itemCleanupWarning = "[ WARNING ]  Item Cleanup Inbound in 60 seconds!",
    mapCleanupWarning = "[ WARNING ]  Map Cleanup Inbound in 60 seconds!",
    itemCleanupFinalWarning = "[ WARNING ]  Item Cleanup Inbound! Brace for impact!",
    mapCleanupFinalWarning = "[ WARNING ]  Map Cleanup Inbound! Brace for impact!",
}
