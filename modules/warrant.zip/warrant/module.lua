﻿MODULE.name = "Warrants"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.version = "Stock"
MODULE.desc = "Adds Warrants"
MODULE.CAMIPrivileges = {
    {
        Name = "Staff Permissions - Can Warrant People",
        MinAccess = "superadmin",
        Description = "Allows access to warranting people.",
    },
    {
        Name = "Staff Permissions - Can See Warrants",
        MinAccess = "superadmin",
        Description = "Allows access to seeing warrants.",
    },
    {
        Name = "Staff Permissions - Can See Warrant Notifications",
        MinAccess = "superadmin",
        Description = "Allows access to seeing warrant notifications.",
    },
}
