﻿NAME = "english"
LANGUAGE = {
    permRemoveSuccess = "Map entity removed.",
    permRemoveInvalid = "This is not a valid map entity",
}
