﻿MODULE.name = "Perma Remove"
MODULE.author = "Boz [Base Code] & Samael [Minor Optimizations]"
MODULE.discord = "bozdev"
MODULE.desc = "Allows staff to permanently remove map entities"
