﻿NAME = "english"
LANGUAGE = {
    AdvertDeductedMessage = "%d %s have been deducted from your wallet for advertising.",
    AdvertInsufficientFunds = "You lack sufficient funds to make an advertisement.",
    AdvertFormat = "[Advertisement by %s]:"
}
