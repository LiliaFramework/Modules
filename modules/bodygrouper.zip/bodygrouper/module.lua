﻿MODULE.name = "Bodygrouper"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.version = "Stock"
MODULE.desc = "Adds a bodygroup menu and bodygroup closet, akin to BodygroupR on GModStore"
lia.config.add("BodyGrouperModel", "Body Grouper Model", "models/props_c17/FurnitureDresser001a.mdl", nil, {
    desc = "Sets the model for the body grouper.",
    category = "Gameplay",
    type = "Generic"
})
