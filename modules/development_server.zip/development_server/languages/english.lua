﻿NAME = "english"
LANGUAGE = {
    devServerUnauthorized = "You are not authorized to join the server during development periods.",
    devServerActive = "The development module is still active!"
}
