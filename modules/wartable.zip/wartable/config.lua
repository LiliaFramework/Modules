﻿lia.config.add("URL", "Map URL", "https://www.worldhistory.org/img/c/p/1600x900/18673.png", nil, {
    desc = "Specifies the map URL used in the game.",
    category = "Map",
    noNetworking = false,
    schemaOnly = false,
    isGlobal = false,
    type = "Generic"
})
