﻿function MODULE:PhysgunPickup(_, ent)
    if ent:GetModel() == "models/william/war_marker/war_marker.mdl" then return false end
end
