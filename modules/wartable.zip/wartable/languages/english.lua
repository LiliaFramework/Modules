﻿NAME = "english"
LANGUAGE = {
    ClearWarTable = "Clear out table.",
    CustomizeMarker = "Customize Marker",
    SetNewMapTitle = "Set new map",
    SetNewMapPrompt = "Input the link to set a new map",
}
