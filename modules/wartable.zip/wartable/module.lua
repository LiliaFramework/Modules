﻿MODULE.name = "War Table"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.version = "Stock"
MODULE.desc = "Adds a interactive War Table"
MODULE.WorkshopContent = {"3431351432"}
