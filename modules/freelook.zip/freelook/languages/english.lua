﻿NAME = "english"
LANGUAGE = {
    freelookEnabled = "Free look Enabled",
    freelookStatus = "Free look is now %s.",
    freeLookError = "Free look is not enabled or cannot be used right now.",
}
