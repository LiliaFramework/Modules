﻿NAME = "english"
LANGUAGE = {
    identifyCorpseQuestion = "Do you want to identify this corpse?",
    identifyCorpse = "Press E to identify corpse",
    identifyCorpseDeclined = "You decided not to identify the corpse.",
    identifyingCorpse = "Identifying corpse...",
    identifiedCorpseMessage = "This corpse appears to belong to %s.",
}
