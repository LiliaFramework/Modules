﻿MODULE.name = "Stun Gun"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.version = "Stock"
MODULE.desc = "An Stun Gun Reworked from CustomHQ"
MODULE.WorkshopContent = {"3432649835"}
