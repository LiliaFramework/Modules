﻿NAME = "english"
LANGUAGE = {
    targetTooFar = "The target is too far away!",
    invalidTarget = "Invalid target or missed shot!",
    stunAttempted = "You were just attempted to be stunned by %s.",
    cannotStunStaff = "You can't stun a staff member!",
    tasedBy = "You have been tased by %s",
    targetTooStunned = "Target is too stunned to react! You have time to tie him up!",
    targetStunnedMove = "You have been able to stand up but you are now too stunned to move!",
    nowAbleToMove = "You are now able to move!",
    targetAbleToMove = "Target is now able to move!",
}
