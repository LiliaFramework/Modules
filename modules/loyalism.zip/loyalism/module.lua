﻿MODULE.name = "Loyalism"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.version = "Stock"
MODULE.desc = "System for loyalist points."
lia.flag.add("T", "Access to /partytier")
