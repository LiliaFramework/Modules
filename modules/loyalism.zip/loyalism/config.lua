﻿MODULE.Tiers = {
    [0] = "No Tier",
    [1] = "Tier I Party Member",
    [2] = "Tier II Party Member",
    [3] = "Tier III Party Member",
    [4] = "Tier IV Party Member",
    [5] = "Tier V Party Member",
}
