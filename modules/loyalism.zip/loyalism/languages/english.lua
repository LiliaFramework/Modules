﻿NAME = "english"
LANGUAGE = {
    partyTierUpdated = "You have updated %s's Party Tier to %s.",
    partyTierRemoved = "%s has removed your Party Tier!",
    partyTierSet = "You have been set as Party Tier %s.",
}
