﻿NAME = "english"
LANGUAGE = {
    realisticViewEnabled = "Realistic View Enabled",
    realisticViewUsesFullBody = "Realistic View Uses Full Body",
}
