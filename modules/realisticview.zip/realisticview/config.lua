﻿if CLIENT then
    lia.option.add("realisticViewEnabled", "Enable Realistic View", "Enable or disable the realistic view system.", false, nil, {
        category = "View",
        type = "Boolean",
        IsQuick = true
    })

    lia.option.add("realisticViewUseFullBody", "Use Full Body for Realistic View", "Enable or disable full-body angles in realistic view.", false, nil, {
        category = "View",
        type = "Boolean",
        IsQuick = true
    })
end
