﻿NAME = "French"
LANGUAGE = {
    toggleRaiseDesc = "Toggle raising or lowering your weapon.",
    weaponRaiseSpeed = "Weapon Raise Speed",
    weaponRaiseSpeedDesc = "Delay (in seconds) before raising the weapon after switching or reloading.",
}
