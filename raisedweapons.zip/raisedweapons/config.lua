﻿lia.config.add("WeaponRaiseSpeed", "weaponRaiseSpeed", 1, nil, {
    desc = "weaponRaiseSpeedDesc",
    category = "weapons",
    type = "Float",
    min = 0.1,
    max = 5
})
