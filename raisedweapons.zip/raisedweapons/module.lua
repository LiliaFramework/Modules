﻿MODULE.name = "Raised Weapons"
MODULE.versionID = "public_raisedweapons"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds auto-lowering of weapons when running, a raise delay set by WeaponRaiseSpeed, prevention of accidental fire, a toggle to keep weapons lowered, and compatibility with melee weapons."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
