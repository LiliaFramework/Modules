﻿MODULE.name = "Instakill"
MODULE.versionID = "public_instakill"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds instant kill on headshots, lethality configurable per weapon, extra tension to combat, and integration with damage numbers."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
