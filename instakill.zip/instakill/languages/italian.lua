﻿NAME = "Italian"
LANGUAGE = {
    instakillModuleName = "Instant Kill",
    instakillModuleDesc = "Applies high damage multipliers for headshots, making them instantly lethal. Each weapon can have its own settings.",
    instantKilling = "Instant Killing",
    instantKillingDesc = "If enabled, headshots instantly kill the target",
    character = "Character",
}
