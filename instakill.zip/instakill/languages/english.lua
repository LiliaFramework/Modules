﻿NAME = "English"
LANGUAGE = {
    instantKilling = "Instant Killing",
    instantKillingDesc = "If enabled, headshots instantly kill the target",
}
