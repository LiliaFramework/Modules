﻿NAME = "Portuguese"
LANGUAGE = {
    instantKilling = "Instant Killing",
    instantKillingDesc = "If enabled, headshots instantly kill the target",
}
