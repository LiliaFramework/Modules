﻿lia.config.add("instakilling", "instantKilling", false, nil, {
    desc = "instantKillingDesc",
    category = "character",
    type = "Boolean"
})
