﻿MODULE.name = "Hospitals"
MODULE.versionID = "public_hospitals"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds respawning of players at hospitals with support for multiple hospital spawn locations on different maps."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
