﻿NAME = "Italian"
LANGUAGE = {
    moneyLossMessage = "Medical fees cost you %s.",
    enableHospitals = "Enable Hospitals",
    enableHospitalsDesc = "Enables or disables hospital respawn functionality.",
    death = "Death",
    loseMoneyOnDeath = "Lose Money On Death",
    loseMoneyOnDeathDesc = "Determines if players lose money upon death.",
    deathMoneyLossPercentage = "Death Money Loss Percentage",
    deathMoneyLossPercentageDesc = "Percentage of money lost upon death.",
}
