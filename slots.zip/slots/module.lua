﻿MODULE.name = "Slot Machine"
MODULE.uniqueID = "public_slots"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.21
MODULE.desc = "Adds a slot machine minigame, a workshop model for the machine, handling of payouts to winners, customizable payout odds, and sound and animation effects."
MODULE.WorkshopContent = "3527541056"
