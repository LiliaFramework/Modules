﻿MODULE.name = "Slot Machine"
MODULE.versionID = "public_slots"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds a slot machine minigame, a workshop model for the machine, handling of payouts to winners, customizable payout odds, and sound and animation effects."
MODULE.WorkshopContent = "3527541056"
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
