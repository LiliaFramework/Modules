﻿MODULE.GamblingPrice = 13
MODULE.JackpotChance = 32
MODULE.TripleBarClover = 200
MODULE.SingleBarDollarSign = 50
MODULE.Lucky7Diamond = 500
MODULE.HorseShoeDoubleBar = 100
