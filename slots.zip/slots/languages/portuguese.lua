﻿NAME = "Portuguese"
LANGUAGE = {
    slotNotEnoughMoney = "You don't have enough money!",
    slotPayout = "Your payout is %sT",
}
