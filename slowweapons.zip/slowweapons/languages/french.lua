﻿NAME = "French"
LANGUAGE = {}