﻿NAME = "German"
LANGUAGE = {}