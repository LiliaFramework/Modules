﻿NAME = "Portuguese"
LANGUAGE = {}