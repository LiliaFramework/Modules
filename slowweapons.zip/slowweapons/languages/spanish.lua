﻿NAME = "Spanish"
LANGUAGE = {}