﻿MODULE.name = "Slow Weapons"
MODULE.versionID = "public_slowweapons"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds slower movement while holding heavy weapons, speed penalties defined per weapon, encouragement for strategic choices, customizable weapon speed table, and automatic speed restore when switching."
MODULE.WeaponsSpeed = {
    ["fo3_fatman"] = 130,
}

MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
