﻿lia.command.add("sendCaption", {
    adminOnly = true,
    arguments = {
        {
            name = "target",
            type = "player"
        },
        {
            name = "caption",
            type = "string"
        },
        {
            name = "duration",
            type = "number",
            optional = true
        }
    },
    desc = "sendCaptionDesc",
    AdminStick = {
        Name = "sendCaptionDesc",
        Category = "captions"
    },
    onRun = function(client, arguments)
        local target = lia.util.findPlayer(client, arguments[1])
        local text = arguments[2]
        local duration = tonumber(arguments[3]) or 5
        if not target or not IsValid(target) then
            client:notify("Target not found.")
            return
        end

        if text then
            lia.caption.start(target, text, duration)
        else
            client:notify("You must specify caption text.")
        end
    end
})

lia.command.add("broadcastCaption", {
    adminOnly = true,
    arguments = {
        {
            name = "caption",
            type = "string"
        },
        {
            name = "duration",
            type = "number",
            optional = true
        }
    },
    desc = "broadcastCaptionDesc",
    onRun = function(client, arguments)
        local text = arguments[1]
        local duration = tonumber(arguments[2]) or 5
        if text then
            for _, target in player.Iterator() do
                lia.caption.start(target, text, duration)
            end
        else
            client:notify("You must specify text to broadcast.")
        end
    end
})
