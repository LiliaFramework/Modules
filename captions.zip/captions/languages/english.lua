﻿NAME = "English"
LANGUAGE = {
    broadcastCaptionDesc = "Send a caption to everyone.",
    broadcastCaptionError = "You must specify text to broadcast.",
    sendCaptionDesc = "Send a caption to a player.",
    sendCaptionError = "You must specify caption text.",
    captions = "Captions",
}
