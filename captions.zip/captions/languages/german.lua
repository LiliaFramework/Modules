﻿NAME = "German"
LANGUAGE = {
    broadcastCaptionDesc = "Sende einen Untertitel an alle.",
    broadcastCaptionError = "Du musst Text zum Senden angeben.",
    sendCaptionDesc = "Sende einen Untertitel an einen Spieler.",
    sendCaptionError = "Du musst Untertitel-Text angeben.",
    captions = "Untertitel",
}
