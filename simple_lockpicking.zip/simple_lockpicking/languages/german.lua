﻿NAME = "German"
LANGUAGE = {
    targetUnlocked = "Target is already unlocked.",
    lockpickLog = "%s lockpicked %s",
}
