﻿function MODULE:PlayerLoadout(ply)
    ply:setNetVar("isPicking", false)
end
