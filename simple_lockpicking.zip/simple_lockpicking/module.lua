﻿MODULE.name = "Simple Lockpicking"
MODULE.versionID = "public_simple_lockpicking"
MODULE.author = "76561198312513285"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds a simple lockpick tool for doors, logging of successful picks, brute-force style gameplay, configurable pick time, and chance for tools to break."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
