﻿MODULE.name = "Cards"
MODULE.versionID = "public_cards"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds a full deck of playing cards that can be shuffled and drawn. Card draws sync to all players for simple in-game minigames."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
