﻿ITEM.name = "Deck of Cards"
ITEM.desc = "Skat-Karte Playing Cards"
ITEM.price = 4
ITEM.model = "models/items/boxsrounds.mdl"
