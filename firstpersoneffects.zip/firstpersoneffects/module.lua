﻿MODULE.name = "First Person Effects"
MODULE.versionID = "public_firstpersoneffects"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds head bob and view sway, camera motion synced to actions, a realistic first-person feel, and adjustable intensity via config."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
