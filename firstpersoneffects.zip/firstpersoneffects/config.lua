﻿lia.option.add("FirstPersonEffects", "First Person Effects", "Toggle realistic first person head bobbing and motion effects", true, nil, {
    category = "Effects",
    type = "Boolean",
    visible = true,
    shouldNetwork = false
})
