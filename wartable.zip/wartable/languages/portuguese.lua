﻿NAME = "Portuguese"
LANGUAGE = {
    ClearWarTable = "Clear War Table",
    CustomizeMarker = "Customize Marker",
    SetNewMapPrompt = "Enter the map name:",
    SetNewMapTitle = "Set War Map",
    previous = "Previous",
    mapUrl = "Map URL",
    mapUrlDesc = "Specifies the map URL used in the game.",
    map = "Map",
}
