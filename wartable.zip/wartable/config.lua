﻿lia.config.add("URL", "mapUrl", "https://i.redd.it/tus9h0hpr89a1.png", nil, {
    desc = "mapUrlDesc",
    category = "map",
    noNetworking = false,
    schemaOnly = false,
    isGlobal = false,
    type = "Generic"
})
