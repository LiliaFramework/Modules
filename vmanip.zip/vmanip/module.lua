﻿MODULE.name = "View Manipulation"
MODULE.uniqueID = "public_vmanip"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.24
MODULE.desc = "Adds VManip animation support, hand gestures for items, functionality within Lilia, API for custom gesture triggers, and fallback animations when VManip is missing."
