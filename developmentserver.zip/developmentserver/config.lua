﻿MODULE.AuthorizedDevelopers = {"76561198312513285"}
lia.config.add("DevServer", "developerServerMode", false, nil, {
    desc = "developerServerModeDesc",
    category = "server",
    type = "Boolean"
})
