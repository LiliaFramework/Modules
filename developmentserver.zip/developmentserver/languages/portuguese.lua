﻿NAME = "Portuguese"
LANGUAGE = {
    devServerActive = "Development server mode is active.",
    devServerUnauthorized = "You are not authorized to join this development server.",
    developerServerMode = "Developer Server Mode",
    developerServerModeDesc = "Enables or disables developer server mode.",
    server = "Server",
}
