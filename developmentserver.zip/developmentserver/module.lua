﻿MODULE.name = "Development Server"
MODULE.versionID = "public_developmentserver"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds a development server mode for testing, the ability to run special development functions, a toggle via configuration, an environment flag for dev commands, and logging of executed dev actions."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
