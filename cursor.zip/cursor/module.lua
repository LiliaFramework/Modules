﻿MODULE.name = "Cursor"
MODULE.versionID = "public_cursor"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds a toggleable custom cursor for the UI, a purely client-side implementation, improved menu navigation, a hotkey to quickly show or hide the cursor, and compatibility with other menu modules."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
