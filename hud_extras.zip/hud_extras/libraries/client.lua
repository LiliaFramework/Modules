﻿local vignetteAlphaGoal, vignetteAlphaDelta = 0, 0
local hasVignetteMaterial = lia.util.getMaterial("vignette.png") ~= "___error"
local mathApproach = math.Approach
local function DrawFPS()
    local fpsFont = lia.config.get("FPSHudFont")
    local f = math.Round(1 / FrameTime())
    MODULE.minFPS = MODULE.minFPS or 60
    local minF = MODULE.minFPS
    MODULE.maxFPS = MODULE.maxFPS or 100
    local maxF = MODULE.maxFPS
    MODULE.barH = MODULE.barH or 1
    MODULE.barH = mathApproach(MODULE.barH, f / maxF * 100, 0.5)
    if f > maxF then MODULE.maxFPS = f end
    if f < minF then MODULE.minFPS = f end
    local x = ScrW() - 10
    local centerY = ScrH() / 2
    draw.SimpleText(f .. " FPS", fpsFont, x, centerY + 20, Color(255, 255, 255), TEXT_ALIGN_RIGHT, 1)
    draw.RoundedBox(0, x - 20, centerY - MODULE.barH, 20, MODULE.barH, Color(255, 255, 255))
    draw.SimpleText(L("hudExtrasMaxPrefix") .. " " .. MODULE.maxFPS, fpsFont, x, centerY + 40, Color(150, 255, 150), TEXT_ALIGN_RIGHT, 1)
    draw.SimpleText(L("hudExtrasMinPrefix") .. " " .. MODULE.minFPS, fpsFont, x, centerY + 55, Color(255, 150, 150), TEXT_ALIGN_RIGHT, 1)
end

local function DrawVignette()
    if hasVignetteMaterial then
        local ft = FrameTime()
        local w, h = ScrW(), ScrH()
        vignetteAlphaDelta = mathApproach(vignetteAlphaDelta, vignetteAlphaGoal, ft * 30)
        surface.SetDrawColor(0, 0, 0, 175 + vignetteAlphaDelta)
        surface.SetMaterial(lia.util.getMaterial("vignette.png"))
        surface.DrawTexturedRect(0, 0, w, h)
    end
end



local function canDrawWatermark()
    return lia.config.get("WatermarkEnabled", false) and isstring(lia.config.get("GamemodeVersion", "")) and lia.config.get("GamemodeVersion", "") ~= "" and isstring(lia.config.get("WatermarkLogo", "")) and lia.config.get("WatermarkLogo", "") ~= ""
end

local function drawWatermark()
    local w, h = 64, 64
    local logoPath = lia.config.get("WatermarkLogo", "")
    local ver = tostring(lia.config.get("GamemodeVersion", ""))
    if logoPath ~= "" then
        local logo = lia.util.getMaterial(logoPath, "smooth")
        surface.SetMaterial(logo)
        surface.SetDrawColor(255, 255, 255, 80)
        surface.DrawTexturedRect(5, ScrH() - h - 5, w, h)
    end

    if ver ~= "" then
        surface.SetFont("liaHugeFont")
        local _, ty = surface.GetTextSize(ver)
        surface.SetTextColor(255, 255, 255, 80)
        surface.SetTextPos(15 + w, ScrH() - h / 2 - ty / 2)
        surface.DrawText(ver)
    end
end

function MODULE:HUDPaint()
    local client = LocalPlayer()
    if client:Alive() and client:getChar() then
        if lia.option.get("FPSDraw", false) then DrawFPS() end
        if lia.config.get("Vignette", true) then DrawVignette() end
        if canDrawWatermark() then drawWatermark() end
    end
end




timer.Create("liaVignetteChecker", 1, 0, function()
    local client = LocalPlayer()
    if IsValid(client) then
        local d = {}
        d.start = client:GetPos()
        d.endpos = d.start + Vector(0, 0, 768)
        d.filter = client
        local tr = util.TraceLine(d)
        if tr and tr.Hit then
            vignetteAlphaGoal = 80
        else
            vignetteAlphaGoal = 0
        end
    end
end)