﻿MODULE.name = "Advertisements"
MODULE.versionID = "public_advert"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Implements a paid /advert command for server-wide announcements. Messages are colored, logged, and throttled by a cooldown to curb spam."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
