﻿NAME = "English"
LANGUAGE = {
    advertCommandDesc = "Broadcasts a paid advertisement to all players, charging you money and applying a cooldown.",
    AdvertDeductedMessage = "You paid %s%s for your advertisement.",
    AdvertFormat = "[ADVERT] %s:",
    AdvertInsufficientFunds = "You don't have enough money to advertise.",
    advertCommandCooldownTimed = "Please wait %s seconds before advertising again.",
    advertLog = "%s advertised: %s",
    advertPrice = "Advert Price",
    advertPriceDesc = "The cost of sending an advertisement.",
    advertisements = "Advertisements",
    advertCooldown = "Advert Cooldown",
    advertCooldownDesc = "The cooldown time (in seconds) between advertisements.",
}
