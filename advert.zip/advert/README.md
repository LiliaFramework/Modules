<h1 style="text-align:center; font-size:2rem; font-weight:bold;">About</h1>

**Name:**
Advertisements

**Description:**

Implements a paid /advert command for server-wide announcements. Messages are colored, logged, and throttled by a cooldown to curb spam.

<h2 style="text-align:center; font-size:1.5rem; font-weight:bold;">Main Features</h2>

- Adds a paid /advert command (alias: /advertisement) for server-wide announcements
- Adds colored broadcast messages across the server
- Adds message logging for moderation purposes
- Adds configurable cooldown system to prevent spam
- Adds configurable pricing system
- Adds notifications when players lack funds or are on cooldown

<p align="center"><a href="https://github.com/LiliaFramework/Modules/raw/refs/heads/gh-pages/advert.zip" style="display:inline-block;padding:12px 24px;font-size:1.5rem;font-weight:bold;text-decoration:none;color:#fff;background-color:var(--md-primary-fg-color,#007acc);border-radius:4px;">DOWNLOAD HERE</a></p>
