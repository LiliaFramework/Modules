﻿NAME = "Italian"
LANGUAGE = {
    developmenthudModuleName = "Development HUD",
    developmenthudModuleDesc = "Shows a staff-only HUD with live performance metrics and other development data. Access requires a CAMI privilege and can be toggled as needed.",
    developmentHudFont = "Development HUD Font",
    developmentHudFontDesc = "Font used for all development/staff HUD text",
    fonts = "Fonts",
}
