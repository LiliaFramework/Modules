﻿NAME = "English"
LANGUAGE = {
    staffHUD = "Staff HUD",
    developmentHUD = "Development HUD",
    developmentHudFont = "Development HUD Font",
    developmentHudFontDesc = "Font used for all development/staff HUD text",
    fonts = "Fonts",
}
