﻿NAME = "French"
LANGUAGE = {
    developmentHudFont = "Development HUD Font",
    developmentHudFontDesc = "Font used for all development/staff HUD text",
    fonts = "Fonts",
}
