﻿NAME = "German"
LANGUAGE = {
    detailedDescTitle = "%s's Detailed Description",
    editDescTitle = "Edit Detailed Description",
    openDetDescFallback = "No description available.",
    openDetDescLabel = "Detailed Description",
    refImagePlaceholder = "Image URL",
    setExtDescCommand = "Edit a player's description.",
    viewExtDescCommand = "View your detailed description.",
}
