﻿NAME = "English"
LANGUAGE = {
    changeDescription = "Change Description",
    descriptions = "Descriptions",
    detailedDescTitle = "%s's Detailed Description",
    editDescTitle = "Edit Detailed Description",
    openDetDescFallback = "No description available.",
    openDetDescLabel = "Detailed Description",
    refImagePlaceholder = "Image URL",
    setExtDescCommand = "Edit a player's description.",
    viewExtDescCommand = "View your detailed description."
}
