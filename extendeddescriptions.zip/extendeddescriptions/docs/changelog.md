# Changelog

### Version 1.4

- Changed button component from liaSmallButton to liaButton for consistency

### Version 1.3

- Added comprehensive hooks documentation


### Version 1.2

- Updated function naming convention from PascalCase to camelCase for consistency

### Version 1.1

- Created docs

### Version 1.0

- Initial Release
