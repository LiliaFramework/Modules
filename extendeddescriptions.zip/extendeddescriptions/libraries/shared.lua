﻿lia.char.registerVar("textDetDescData", {
    field = "text_det_desc_data",
    fieldType = "text",
    default = "",
    noDisplay = true,
})

lia.char.registerVar("textDetDescDataURL", {
    field = "text_det_desc_data_url",
    fieldType = "text",
    default = "",
    noDisplay = true,
})
