﻿MODULE.name = "Extended Descriptions"
MODULE.versionID = "public_extendeddescriptions"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds support for long item descriptions, localization for multiple languages, better RP text display, automatic line wrapping, and fallback to short descriptions."
MODULE.Privileges = {
    ["changeDescription"] = {
        Name = "changeDescription",
        MinAccess = "admin",
        Category = "descriptions",
    }
}

MODULE.NetworkStrings = {"EditDetailedDescriptions", "OpenDetailedDescriptions", "SetDetailedDescriptions"}
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
