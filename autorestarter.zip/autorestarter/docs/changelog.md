# Changelog

### Version 1.3

- Added comprehensive configuration documentation
- Configuration updates and improvements

### Version 1.2

- Added comprehensive hooks documentation


### Version 1.1

- Created docs

### Version 1.0

- Initial Release
