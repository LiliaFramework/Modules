﻿MODULE.name = "Map Cleaner"
MODULE.versionID = "public_mapcleaner"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds periodic cleaning of map debris, a configurable interval, reduced server lag, a whitelist for protected entities, and manual cleanup commands."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
