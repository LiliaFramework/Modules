﻿MODULE.name = "Chat Messages"
MODULE.versionID = "public_chatmessages"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Periodically posts automated advert messages in chat on a timer. Keeps players informed with rotating tips even when staff are offline."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
