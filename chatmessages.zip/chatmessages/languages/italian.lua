﻿NAME = "Italian"
LANGUAGE = {
    chatmessagesModuleName = "Chat Messages",
    chatmessagesModuleDesc = "Periodically posts automated advert messages in chat on a timer. Keeps players informed with rotating tips even when staff are offline.",
    chatMessagesInterval = "Chat Messages Interval",
    chatMessagesIntervalDesc = "Time interval (in seconds) between each automatic chat message.",
    chat = "Chat",
}
