﻿NAME = "Portuguese"
LANGUAGE = {
    chatMessagesInterval = "Chat Messages Interval",
    chatMessagesIntervalDesc = "Time interval (in seconds) between each automatic chat message.",
    chat = "Chat",
}
