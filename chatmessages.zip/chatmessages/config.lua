﻿lia.config.add("ChatMessagesInterval", "chatMessagesInterval", 300, nil, {
    desc = "chatMessagesIntervalDesc",
    category = "chat",
    type = "Int",
    min = 10,
    max = 3600
})
