﻿function MODULE:InitializedModules()
    for commandName, data in pairs(self.URLs) do
        local url = data.URL
        lia.command.add(commandName, {
            adminOnly = false,
            desc = "urlCommandDesc",
            onRun = function(client)
                if SERVER then
                    if url and url ~= "" then
                        self:HandleCommunityURL(client, commandName)
                    else
                        client:notify("This URL has not been configured.")
                    end
                end
            end
        })
    end
end
