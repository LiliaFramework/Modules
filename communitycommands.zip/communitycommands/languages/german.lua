﻿NAME = "German"
LANGUAGE = {
    invalidCommand = "Unbekannter Befehl.",
    invalidURLReceived = "Ungültige URL erhalten.",
    urlCommandDesc = "Öffnet den %s Link.",
    urlNotConfig = "Diese URL wurde nicht konfiguriert."
}
