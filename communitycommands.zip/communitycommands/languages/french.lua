﻿NAME = "French"
LANGUAGE = {
    invalidCommand = "Unknown command.",
    invalidURLReceived = "Invalid URL received.",
    urlCommandDesc = "Opens the %s link.",
    urlNotConfig = "This URL has not been configured."
}
