﻿MODULE.name = "Community Commands"
MODULE.versionID = "public_communitycommands"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds chat commands to open community links, easy sharing of workshop and docs, configurable commands via settings, localization for command names, and the ability to add custom URLs."
MODULE.NetworkStrings = {"OpenCommunityURL"}
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
