﻿MODULE.name = "Damage Numbers"
MODULE.versionID = "public_damagenumbers"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds floating combat text when hitting targets, different colors for damage types, display of damage dealt and received, scaling text based on damage amount, and client option to disable numbers."
MODULE.NetworkStrings = {"expDamageNumbers"}
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
