﻿NAME = "French"
LANGUAGE = {
    damageNumberFont = "Damage Number Font",
    damageNumberFontDesc = "Specifies the font family used for floating damage numbers.",
    fonts = "Fonts",
}
