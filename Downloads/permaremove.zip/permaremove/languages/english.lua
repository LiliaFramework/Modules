﻿NAME = "English"
LANGUAGE = {
    permRemoveDesc = "Permanently remove the entity you're looking at.",
    permRemoveInvalid = "You must be looking at a map entity.",
    permRemoveSuccess = "Entity permanently removed."
}
