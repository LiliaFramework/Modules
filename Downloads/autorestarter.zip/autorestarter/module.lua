﻿MODULE.name = "Auto Restarter"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = "1.0.1"
MODULE.public = true
MODULE.desc = "Automatically restarts the server every interval."