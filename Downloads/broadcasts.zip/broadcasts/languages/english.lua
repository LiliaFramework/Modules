﻿NAME = "English"
LANGUAGE = {
    classBroadcastLabel = "[CLASS BROADCAST]",
    classBroadcastNoPermission = "You aren't allowed to send a class broadcast.",
    classBroadcastNoValidClasses = "No valid classes were chosen.",
    classBroadcastSent = "Class broadcast sent.",
    classBroadcastSentTo = "Sent to: %s",
    classBroadcastTitle = "Send a broadcast to selected classes.",
    factionBroadcastLabel = "[FACTION BROADCAST]",
    factionBroadcastNoPermission = "You aren't allowed to send a faction broadcast.",
    factionBroadcastNoValidFactions = "No valid factions were chosen.",
    factionBroadcastSent = "Faction broadcast sent.",
    factionBroadcastSentTo = "Sent to: %s",
    factionBroadcastTitle = "Send a broadcast to selected factions.",
    selectClassesPrompt = "Choose classes to send to:",
    selectFactionsPrompt = "Choose factions to send to:",
}
