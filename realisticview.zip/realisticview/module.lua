﻿MODULE.name = "Realistic View"
MODULE.versionID = "public_realisticview"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds a first-person view that shows the full body, immersive camera transitions, compatibility with animations, smooth leaning animations, and optional third-person override."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
