﻿MODULE.name = "Alcoholism"
MODULE.versionID = "public_alcoholism"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds drinkable alcohol that increases a player's intoxication level. High BAC blurs vision and slows movement until the effect wears off."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
