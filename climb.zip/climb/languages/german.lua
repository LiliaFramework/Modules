NAME = "German"
LANGUAGE = {}