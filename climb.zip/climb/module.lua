﻿MODULE.name = "Climbing"
MODULE.versionID = "public_climb"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds the ability to climb ledges using movement keys, custom climbing animations, and hooks for climb attempts."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
