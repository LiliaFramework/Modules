﻿MODULE.name = "NPC Spawner"
MODULE.versionID = "public_npcspawner"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds automatic NPC spawns at points, the ability for admins to force spawns, logging of spawn actions, and configuration for spawn intervals."
MODULE.Privileges = {
    ["forceNPCSpawn"] = {
        Name = "forceNPCSpawn",
        MinAccess = "superadmin",
        Category = "spawnPermissions",
    }
}

MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
