﻿MODULE.name = "Free Look"
MODULE.versionID = "public_freelook"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds the ability to look around without turning the body, a toggle key similar to EFT, movement direction preservation, and adjustable sensitivity while freelooking."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
