﻿NAME = "Portuguese"
LANGUAGE = {
    enableFreelookLabel = "Enable freelook",
    freelookOffMessage = "Freelook disabled.",
    freelookOnMessage = "Freelook enabled."
}
