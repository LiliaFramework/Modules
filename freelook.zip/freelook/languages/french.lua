﻿NAME = "French"
LANGUAGE = {
    enableFreelookLabel = "Enable freelook",
    freelookOffMessage = "Freelook disabled.",
    freelookOnMessage = "Freelook enabled."
}
