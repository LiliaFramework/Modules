﻿MODULE.OverrideCharLimit = {
    ["founder"] = 10,
    ["superadmin"] = 3,
    ["admin"] = 3,
    ["user"] = 2
}

MODULE.DonatorGroups = {
    ["vip"] = "pet"
}

MODULE.GroupInventorySize = {
    ["superadmin"] = {10, 10}
}

MODULE.DonatorWeapons = {
    ["76561198312513285"] = {"weapon_smg1", "weapon_shotgun", "weapon_rpg", "weapon_pistol"},
}
