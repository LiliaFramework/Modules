﻿MODULE.name = "Enhanced Death"
MODULE.uniqueID = "public_enhanceddeath"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.20
MODULE.desc = "Adds respawning of players at hospitals, a medical recovery system, support for multiple hospital spawns, configurable respawn delays, and integration with death logs."
