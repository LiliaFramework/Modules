﻿NAME = "Spanish"
LANGUAGE = {
    playerJoined = "%s has joined the server.",
    playerLeft = "%s has left the server."
}
