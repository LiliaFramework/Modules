﻿NAME = "Italian"
LANGUAGE = {
    playerJoined = "%s has joined the server.",
    playerLeft = "%s has left the server."
}
