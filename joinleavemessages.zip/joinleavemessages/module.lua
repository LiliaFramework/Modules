﻿MODULE.name = "Join Leave Messages"
MODULE.versionID = "public_joinleavemessages"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds announcements when players join, notifications on disconnect, improved community awareness, relay of messages to Discord, and per-player toggle to hide messages."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
