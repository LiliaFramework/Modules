﻿MODULE.name = "Word Filter"
MODULE.versionID = "public_wordfilter"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds chat word filtering, blocking of banned phrases, an easy-to-extend list, and admin commands to modify the list."
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
