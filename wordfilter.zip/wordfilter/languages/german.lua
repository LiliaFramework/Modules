﻿NAME = "German"
LANGUAGE = {
    usedFilteredWord = "You just used a filtered word!",
}
