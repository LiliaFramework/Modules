﻿NAME = "English"
LANGUAGE = {
    usedFilteredWord = "You just used a filtered word!"
}
