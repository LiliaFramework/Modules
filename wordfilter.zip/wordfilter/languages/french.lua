﻿NAME = "French"
LANGUAGE = {
    usedFilteredWord = "You just used a filtered word!",
}
