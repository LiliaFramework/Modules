﻿NAME = "Spanish"
LANGUAGE = {
    usedFilteredWord = "You just used a filtered word!",
}
