﻿NAME = "Italian"
LANGUAGE = {
    usedFilteredWord = "You just used a filtered word!",
}
