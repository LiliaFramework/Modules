﻿function MODULE:LoadData()
    if not SERVER then return end
    local stored = lia.data.get("wordfilter_words", {})
    if istable(stored) then
        for _, word in ipairs(stored) do
            if not table.HasValue(self.WordBlackList, word) then table.insert(self.WordBlackList, word) end
        end
    end
end

function MODULE:SaveData()
    if not SERVER then return end
    lia.data.set("wordfilter_words", self.WordBlackList)
end

function MODULE:AddBlacklistedWord(word)
    if not word then return end
    if table.HasValue(self.WordBlackList, word) then return end
    table.insert(self.WordBlackList, word)
    self:SaveData()
end

function MODULE:RemoveBlacklistedWord(word)
    if not word then return end
    for i, v in ipairs(self.WordBlackList) do
        if v == word then
            table.remove(self.WordBlackList, i)
            self:SaveData()
            break
        end
    end
end

function MODULE:PlayerSay(ply, text)
    local lowerText = text:lower()
    for _, bad in pairs(self.WordBlackList) do
        if lowerText:find(bad, 1, true) then
            ply:notifyLocalized("usedFilteredWord")
            return ""
        end
    end
end
