﻿ITEM.name = "Broken Radio"
ITEM.desc = "A Broken Radio"
ITEM.model = "models/danradio/w_radio.mdl"
