﻿MODULE.name = "Radio"
MODULE.versionID = "public_radio"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 1.0
MODULE.desc = "Adds a radio chat channel for players, font configuration via RadioFont, workshop models for radios, frequency channels for groups, and handheld radio items."
MODULE.WorkshopContent = "3527548881"
MODULE.NetworkStrings = {"radioAdjust"}
MODULE.Changelog = {
    ["1.0"] = {"Initial Release"},
}
