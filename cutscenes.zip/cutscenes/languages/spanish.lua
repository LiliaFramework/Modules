﻿NAME = "Spanish"
LANGUAGE = {
    cutsceneCommandDesc = "Play a cutscene for a target player.",
    globalCutsceneCommandDesc = "Play a cutscene for everyone.",
    globalCutscenePrompt = "Select a cutscene to play globally:",
    invalidCutscene = "Invalid cutscene selected.",
    selectCutscenePrompt = "Select a cutscene to play:",
    selectCutsceneTitle = "Choose Cutscene",
    cutscenes = "Cutscenes",
}
