﻿lia.config.add("BodyGrouperModel", "bodyGrouperModel", "models/props_c17/FurnitureDresser001a.mdl", nil, {
    desc = "bodyGrouperModelDesc",
    category = "gameplay",
    type = "Generic"
})
