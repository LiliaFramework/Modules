﻿NAME = "German"
LANGUAGE = {
    bodygroupChanged = "Du hast %s Bodygroups geändert.",
    bodygroupChangedBy = "Deine Bodygroups wurden von %s geändert.",
    bodygroupMenuTitle = "Bodygroup Menü",
    invalidBodygroup = "Ungültige Bodygroup-Auswahl.",
    invalidSkin = "Ungültiger Skin ausgewählt.",
    noBodygroupsnSkins = "Dieses Modell hat keine Bodygroups oder Skins.",
    rotateInstruction = "Halte %s/%s um das Modell zu drehen.",
    viewBodygroupsDesc = "Betrachte oder bearbeite die Bodygroups eines Spielers.",
    bodygrouper = "Bodygroup Editor",
    bodyGrouperModel = "Body Grouper Model",
    bodyGrouperModelDesc = "Sets the model for the body grouper.",
    gameplay = "Gameplay",
}
