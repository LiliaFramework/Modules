﻿NAME = "Italian"
LANGUAGE = {
    bodygrouperModuleName = "Editor Bodygroup",
    bodygrouperModuleDesc = "Spawna un armadio bodygroup dove i giocatori possono modificare i bodygroup del loro modello. Gli admin possono ispezionare altri e configurare il modello dell'armadio.",
    bodygroupChanged = "Hai cambiato %s bodygroup.",
    bodygroupChangedBy = "I tuoi bodygroup sono stati cambiati da %s.",
    bodygroupMenuTitle = "Menu Bodygroup",
    invalidBodygroup = "Selezione bodygroup non valida.",
    invalidSkin = "Skin selezionata non valida.",
    noBodygroupsnSkins = "Questo modello non ha bodygroup o skin.",
    rotateInstruction = "Tieni premuto %s/%s per ruotare il modello.",
    viewBodygroupsDesc = "Visualizza o modifica i bodygroup di un giocatore.",
    bodygrouper = "Editor Bodygroup",
    bodyGrouperModel = "Body Grouper Model",
    bodyGrouperModelDesc = "Sets the model for the body grouper.",
    gameplay = "Gameplay",
}
