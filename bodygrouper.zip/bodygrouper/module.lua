﻿MODULE.name = "BodyGroup Closet"
MODULE.versionID = "public_bodygrouper"
MODULE.author = "Samael"
MODULE.discord = "@liliaplayer"
MODULE.version = 2.1
MODULE.desc = "Spawns a bodygroup closet where players can edit their model's bodygroups. Admins may inspect others and configure the closet's model."
MODULE.Privileges = {
    ["manageBodygroups"] = {
        Name = "manageBodygroups",
        MinAccess = "admin",
        Category = "bodygroups",
    },
    ["changeBodygroups"] = {
        Name = "changeBodygroups",
        MinAccess = "admin",
        Category = "bodygroups",
    }
}

MODULE.NetworkStrings = {"BodygrouperMenu", "BodygrouperMenuClose", "BodygrouperMenuCloseClientside"}
